// CHIEF public API: /api/v1/*   Auth: CHIEF_API_KEY via x-api-key header, Bearer token, or ?key=
import {
  json, CORS, COLS, isApiClient, loadState, updateState, buildItem, briefingText,
  jobFromPayload, classifyJob, ownerFor, confirmationEmail, localToDate, dateToLocal, uid, getJSON, setJSON,
  fetchEquipment, equipmentLine,
} from "../lib/core.mjs";

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  if (!process.env.CHIEF_API_KEY) return json({ error: "API is off: set CHIEF_API_KEY in Netlify, then redeploy." }, 503);
  if (!isApiClient(req)) return json({ error: "missing or wrong API key" }, 401);

  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/v1\/?/, "").replace(/\/+$/, "").split("/").filter(Boolean);
  const [a, b] = parts;

  try {
    // GET /api/v1 or /api/v1/state → everything
    if (!a || a === "state") {
      if (req.method !== "GET") return json({ error: "use GET" }, 405);
      const { state } = await loadState();
      const { chat, tombstones, ...rest } = state;
      return json(rest);
    }

    // GET /api/v1/briefing → plain-text summary of today (for Siri Shortcuts, Alexa, texts)
    if (a === "briefing") {
      const { state } = await loadState();
      let text = briefingText(state);
      try { if (process.env.EQUIPMENT_STATUS_URL) text += " " + equipmentLine(await fetchEquipment()); } catch (e) {}
      return url.searchParams.get("format") === "json" ? json({ text }) : new Response(text, { headers: { "content-type": "text/plain; charset=utf-8", ...CORS } });
    }

    // GET /api/v1/today → today's events, reminders and open duties as JSON
    if (a === "today") {
      const { state } = await loadState();
      const day = dateToLocal(new Date()).slice(0, 10);
      return json({
        date: day,
        events: state.events.filter((e) => (e.start || "").startsWith(day)).sort((x, y) => x.start.localeCompare(y.start)),
        reminders: state.reminders.filter((r) => !r.done && (r.due || "").slice(0, 10) <= day),
        duties: state.duties.map((d) => ({ ...d, doneToday: d.lastDone === day })),
        emailsToSend: state.emails.filter((e) => e.status !== "sent"),
      });
    }

    // GET /api/v1/equipment → live equipment status (from the Firehouse equipment app)
    if (a === "equipment") {
      try { return json(await fetchEquipment()); }
      catch (e) { return json({ error: String(e.message || e) }, e.code === "not_configured" ? 503 : 502); }
    }

    // POST /api/v1/smartmoving  → SmartMoving webhook / Zapier / Make. One job or {jobs:[...]}.
    if (a === "smartmoving") {
      if (req.method === "GET" && b === "last") return json((await getJSON("lastWebhook", null)) || { note: "nothing received yet" });
      if (req.method !== "POST") return json({ error: "use POST" }, 405);
      const payload = await req.json().catch(() => null);
      if (!payload) return json({ error: "send JSON" }, 400);
      await setJSON("lastWebhook", { receivedAt: new Date().toISOString(), payload });
      const list = Array.isArray(payload) ? payload : Array.isArray(payload.jobs) ? payload.jobs : [payload];
      const { result } = await updateState((state) => importJobs(state, list));
      return json(result, result.added || result.updated ? 200 : 422);
    }

    // Collections: events | reminders | notes | crew | emails | duties
    if (!COLS.includes(a)) return json({ error: `unknown path. Try: ${COLS.join(", ")}, today, briefing, equipment, smartmoving` }, 404);

    if (req.method === "GET") {
      const { state } = await loadState();
      if (b) { const it = state[a].find((x) => x.id === b); return it ? json(it) : json({ error: "not found" }, 404); }
      let items = state[a];
      const since = url.searchParams.get("since"); // e.g. ?since=2026-11-14 filters events/reminders by date
      if (since && (a === "events" || a === "reminders")) items = items.filter((x) => (x.start || x.due || "") >= since);
      return json(items);
    }

    if (req.method === "POST" && !b) {
      const body = await req.json().catch(() => null);
      if (!body) return json({ error: "send JSON" }, 400);
      const list = Array.isArray(body) ? body : [body];
      if (list.length > 200) return json({ error: "max 200 items per request" }, 400);
      const built = list.map((x) => buildItem(a, { source: "api", ...x }));
      const bad = built.findIndex((x) => x.error);
      if (bad >= 0) return json({ error: built[bad].error, index: bad }, 400);
      const items = built.map((x) => x.item);
      if (a !== "events") items.forEach((x) => delete x.source);
      await updateState((state) => { state[a].push(...items); });
      return json(Array.isArray(body) ? items : items[0], 201);
    }

    if ((req.method === "PATCH" || req.method === "PUT") && b) {
      const body = await req.json().catch(() => null);
      if (!body) return json({ error: "send JSON" }, 400);
      const { result } = await updateState((state) => {
        const i = state[a].findIndex((x) => x.id === b);
        if (i < 0) return { error: "not found", status: 404 };
        const merged = req.method === "PATCH" ? body : { ...body };
        const r = buildItem(a, merged, req.method === "PATCH" ? state[a][i] : { id: b });
        if (r.error) return { error: r.error, status: 400 };
        state[a][i] = r.item;
        return { item: r.item };
      });
      return result.error ? json({ error: result.error }, result.status) : json(result.item);
    }

    if (req.method === "DELETE" && b) {
      const { result } = await updateState((state) => {
        const n = state[a].length;
        state[a] = state[a].filter((x) => x.id !== b);
        if (state[a].length === n) return { found: false };
        state.tombstones[b] = Date.now();
        return { found: true };
      });
      return result.found ? json({ deleted: b }) : json({ error: "not found" }, 404);
    }

    return json({ error: "method not allowed" }, 405);
  } catch (e) {
    return json({ error: String(e.message || e) }, 500);
  }
};

// Adds or updates SmartMoving jobs, plus a crew-call reminder (moves) and a confirmation draft (has email).
function importJobs(state, list) {
  const team = state.settings.team;
  const out = { added: 0, updated: 0, skipped: 0, reminders: 0, emails: 0, ids: [] };
  const nowLocal = dateToLocal(new Date());
  for (const raw of list.slice(0, 200)) {
    const j = jobFromPayload(raw);
    if (!j.start) { out.skipped++; continue; }
    const smKey = j.jobId ? `sm:${j.jobId}` : `${(j.customer || j.title).toLowerCase()}|${j.start}|${j.type.toLowerCase()}`;
    const type = j.type || classifyJob(j.title);
    const fields = {
      title: j.title, start: j.start, location: j.location, kind: type, owner: j.crewLead || ownerFor(type, team),
      customer: j.customer, phone: j.phone, email: j.email, notes: [j.jobId ? `SmartMoving #${j.jobId}` : "", j.notes].filter(Boolean).join(" · "),
      source: "SmartMoving", smKey, updatedAt: Date.now(),
    };
    const existing = state.events.find((e) => e.smKey === smKey);
    if (existing) {
      if (existing.start !== fields.start) existing.alerted = false;
      // Only overwrite what this update actually contains, so a partial webhook doesn't erase a phone or email.
      for (const [k, v] of Object.entries(fields)) if (v !== "" && v != null) existing[k] = v;
      if (!j.customer) existing.title = existing.title || fields.title;
      out.updated++; out.ids.push(existing.id); continue;
    }
    const ev = { id: uid(), alerted: false, ...fields };
    state.events.push(ev); out.added++; out.ids.push(ev.id);
    if (type === "Move" && j.start > nowLocal) {
      const d = localToDate(j.start); const before = new Date(d.getTime() - 864e5);
      const due = dateToLocal(before).slice(0, 10) + "T16:00";
      if (due > nowLocal) {
        state.reminders.push({ id: uid(), text: `Call the crew about ${j.customer || "the"} move on ${d.toLocaleDateString("en-US", { timeZone: process.env.CHIEF_TIMEZONE || "America/Chicago", weekday: "short", month: "short", day: "numeric" })}`, due, crewName: "crew", repeat: "", done: false, fired: false, updatedAt: Date.now() });
        out.reminders++;
      }
    }
    if (ev.email && j.start > nowLocal) {
      const m = confirmationEmail(ev, state.settings.business);
      state.emails.push({ id: uid(), ...m, status: "draft", alerted: false, updatedAt: Date.now() });
      out.emails++;
    }
  }
  return out;
}

export const config = { path: ["/api/v1", "/api/v1/*"] };
