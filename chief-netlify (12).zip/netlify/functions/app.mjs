// Endpoints used by the CHIEF web app itself (signed in with CHIEF_PASSWORD).
import { json, isAppUser, loadState, updateState, mergeStates, CORS, fetchEquipment } from "../lib/core.mjs";

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  const path = new URL(req.url).pathname.replace(/\/+$/, "");

  if (!process.env.CHIEF_PASSWORD) return json({ error: "Set CHIEF_PASSWORD in Netlify environment variables, then redeploy." }, 500);
  if (!isAppUser(req)) return json({ error: "wrong password" }, 401);

  // GET /api/state → everything.  PUT /api/state {state} → merge and save, returns the merged state.
  if (path === "/api/state") {
    if (req.method === "GET") {
      const { state } = await loadState();
      return json({ state, rev: state.rev || 0, ai: !!process.env.ANTHROPIC_API_KEY, push: !!(process.env.NTFY_TOPIC || process.env.TWILIO_ACCOUNT_SID) });
    }
    if (req.method === "PUT") {
      const body = await req.json().catch(() => null);
      if (!body || !body.state) return json({ error: "state required" }, 400);
      const { state } = await updateState((cur) => {
        const merged = mergeStates(cur, body.state);
        Object.keys(cur).forEach((k) => delete cur[k]);
        Object.assign(cur, merged);
      });
      return json({ state, rev: state.rev });
    }
  }

  // POST /api/ai → forwards a Messages API request to Anthropic, so the key never reaches the browser.
  if (path === "/api/ai" && req.method === "POST") {
    if (!process.env.ANTHROPIC_API_KEY) return json({ error: "AI is off: add ANTHROPIC_API_KEY in Netlify." }, 501);
    const body = await req.json().catch(() => ({}));
    const payload = {
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
      max_tokens: Math.min(Number(body.max_tokens) || 1500, 4000),
      messages: Array.isArray(body.messages) ? body.messages : [],
    };
    if (body.system) payload.system = String(body.system).slice(0, 20000);
    if (Array.isArray(body.tools) && body.tools.length) payload.tools = body.tools;
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await r.json().catch(() => ({ error: "bad response from Anthropic" }));
    return json(data, r.ok ? 200 : r.status === 429 ? 429 : 502);
  }

  // GET /api/equipment → live status from the Firehouse equipment app
  if (path === "/api/equipment" && req.method === "GET") {
    try { return json(await fetchEquipment({ maxAgeMs: new URL(req.url).searchParams.get("fresh") ? 0 : 60000 })); }
    catch (e) { return json({ error: String(e.message || e), code: e.code || "error" }, e.code === "not_configured" ? 503 : 502); }
  }

  return json({ error: "not found" }, 404);
};

export const config = { path: ["/api/state", "/api/ai", "/api/equipment"] };
