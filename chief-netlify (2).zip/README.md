# CHIEF — Daily Assistant (Netlify version, with API)

CHIEF runs your daily duties for Firehouse Movers: schedule, reminders and crew calls, daily checklist, notes,
email drafts and SmartMoving jobs. It talks and listens, and it has a REST API so other apps can read and add things.

```
public/                 the CHIEF app (index.html), API docs (api.html), icons
netlify/functions/
  app.mjs               sign-in, syncing, and the AI connection used by the app
  v1.mjs                the public API at /api/v1/*  (includes the SmartMoving webhook)
  alerts.mjs            runs every 5 minutes and pushes due reminders to your phone
netlify/lib/core.mjs    shared code (storage, merging, time zones, notifications)
```

Data is stored in **Netlify Blobs** on your own Netlify account. Nothing else to set up.

---

## 1. Put it on Netlify (about 10 minutes)

The functions need one package (`@netlify/blobs`), so let Netlify build it from GitHub:

1. Create a new **GitHub** repository (e.g. `chief-assistant`) and upload everything in this folder
   (on github.com: *Add file → Upload files*, drag the folder contents in, *Commit*).
2. In **Netlify**: *Add new site → Import an existing project → GitHub* → pick the repo.
   Leave the build settings as they are (they come from `netlify.toml`) and click **Deploy**.
3. Optional: *Site configuration → Change site name* to something like `firehouse-chief`
   so the address is `https://firehouse-chief.netlify.app`.

> Prefer the command line? Install Node, then in this folder run `npm install` and `npx netlify-cli deploy --prod`.

## 2. Add your settings (environment variables)

Netlify → your site → **Site configuration → Environment variables → Add a variable**:

| Name | Required | What to put |
|---|---|---|
| `CHIEF_PASSWORD` | yes | The password you'll type to open CHIEF |
| `CHIEF_API_KEY` | yes, for the API | A long random string (30+ characters). Other apps use this |
| `ANTHROPIC_API_KEY` | for the AI | From console.anthropic.com → API Keys. Pay-as-you-go, typically a few cents a day for one person |
| `ANTHROPIC_MODEL` | no | Defaults to `claude-sonnet-5-5`. Use `claude-haiku-5-5` to cut cost |
| `CHIEF_TIMEZONE` | no | Defaults to `America/Chicago` |
| `NTFY_TOPIC` | for phone alerts | See step 3 |
| `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM`, `ALERT_PHONE` | for text-message alerts | See step 3 |

After adding or changing variables: **Deploys → Trigger deploy → Deploy site**.

## 3. Alerts on your phone when CHIEF is closed

The `alerts` function checks every 5 minutes and sends: reminders and crew calls when due (with the crew's
numbers), daily duties at their time, events 15 minutes before, and emails when it's time to send them.

**Free option: ntfy push notifications**
1. Install the **ntfy** app (iPhone or Android).
2. Make up a long, hard-to-guess topic name, e.g. `firehouse-chief-7k2q9x4m` (anyone who knows the name can read it).
3. In the app: **+ / Subscribe to topic** → enter that name.
4. In Netlify add `NTFY_TOPIC` = that name, and redeploy.
   Notifications include a **Call** button for the crew member and open CHIEF when tapped.

**Text messages: Twilio** (paid, needs a Twilio number)
Set `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM` (your Twilio number, like `+15551234567`)
and `ALERT_PHONE` (your cell; several numbers can be separated by commas). You can use ntfy and Twilio together.

## 4. Use it

* Open your site, enter `CHIEF_PASSWORD`. It stays signed in on that device.
* **Phone:** open it in Safari or Chrome → *Share → Add to Home Screen* for an app icon.
* **Voice:** tap the reactor and talk. Listening works in Chrome, Edge and Safari. CHIEF answers out loud
  with your device's voice (choose one in Settings).
* Everything syncs between your phone and computer within about 30 seconds.

## 5. The API

Full docs with examples are built in at **`https://YOUR-SITE.netlify.app/api.html`**.

Quick look:
```
GET    /api/v1/today                 today's jobs, reminders, duties
GET    /api/v1/briefing              spoken-style summary (great for Siri Shortcuts)
GET    /api/v1/{collection}          events | reminders | notes | crew | emails | duties
POST   /api/v1/{collection}          add
PATCH  /api/v1/{collection}/{id}     change
DELETE /api/v1/{collection}/{id}     delete
POST   /api/v1/smartmoving           SmartMoving webhook / Zapier / Make
```
Auth: header `x-api-key: YOUR_KEY` (or `?key=YOUR_KEY` in the URL).

### SmartMoving → CHIEF automatically
* **With SmartMoving's Open API (Premium, webhooks):** add a webhook for booked jobs pointing to
  `https://YOUR-SITE.netlify.app/api/v1/smartmoving?key=YOUR_KEY`.
* **Without it:** a Zapier or Make scenario that watches SmartMoving (or the emailed scheduled report) can POST
  each job to the same URL.
* Or keep pasting / uploading in CHIEF with the **⇩ SMARTMOVING** button. It still works.

Rescheduled jobs that come in again with the same job number update the existing entry instead of duplicating it.
If something doesn't appear, open `/api/v1/smartmoving/last?key=YOUR_KEY` to see exactly what was received.

## Troubleshooting
* **"Set CHIEF_PASSWORD…"** — add the variable and redeploy.
* **AI says it's off** — add `ANTHROPIC_API_KEY` and redeploy. Everything else works without it.
* **No phone alerts** — check `NTFY_TOPIC` matches the topic in the app exactly; Netlify → *Logs → Functions → alerts* shows each run.
* **Green dot at the top** = synced. **Amber** = can't reach the server right now; changes are kept on the device and sync later.
