// Runs every 5 minutes on Netlify. Pushes due reminders, daily duties, upcoming events and emails-to-send
// to your phone (ntfy and/or Twilio SMS), even when the CHIEF page is closed.
import { loadState, getJSON, setJSON, notify, localToDate, dateToLocal, fmtTime } from "../lib/core.mjs";

const isWholeCrew = (n) => /^(the\s+)?(crew|whole crew|all|everyone|team|all crew)$/i.test(String(n || "").trim());

export async function runAlerts(now = new Date()) {
  if (!process.env.NTFY_TOPIC && !process.env.TWILIO_ACCOUNT_SID) return { skipped: "no NTFY_TOPIC or Twilio settings" };
  const { state } = await loadState();
  const log = await getJSON("pushlog", {});
  const addr = state.settings.address || "Sir";
  const today = dateToLocal(now).slice(0, 10);
  const nowMs = now.getTime();
  const jobs = [];
  const findCrew = (name) => {
    if (!name || isWholeCrew(name)) return null;
    const n = name.toLowerCase();
    return state.crew.find((c) => c.name.toLowerCase() === n) || state.crew.find((c) => c.name.toLowerCase().startsWith(n)) || null;
  };

  for (const r of state.reminders) {
    if (r.done || !r.due) continue;
    const t = localToDate(r.due); if (!t) continue;
    const key = `rem:${r.id}:${r.due}`;
    if (log[key] || t.getTime() > nowMs || nowMs - t.getTime() > 30 * 60e3) continue;
    const c = findCrew(r.crewName);
    let msg = r.text;
    if (c && c.phone) msg += ` — ${c.name} ${c.phone}`;
    if (isWholeCrew(r.crewName)) { const list = state.crew.filter((x) => x.phone).map((x) => `${x.name} ${x.phone}`); if (list.length) msg += `\n${list.join("\n")}`; }
    jobs.push({ key, title: `Reminder - ${fmtTime(r.due)}`, message: msg, callName: c?.name, callPhone: c?.phone });
  }
  for (const d of state.duties) {
    if (!d.time || d.lastDone === today) continue;
    const local = `${today}T${d.time}`; const t = localToDate(local);
    const key = `duty:${d.id}:${today}`;
    if (log[key] || t.getTime() > nowMs || nowMs - t.getTime() > 30 * 60e3) continue;
    jobs.push({ key, title: `Daily duty - ${fmtTime(local)}`, message: d.text });
  }
  for (const e of state.events) {
    if (!e.start) continue;
    const t = localToDate(e.start); if (!t) continue;
    const mins = (t.getTime() - nowMs) / 60e3;
    const key = `ev:${e.id}:${e.start}`;
    if (log[key] || mins > 15 || mins < -5) continue;
    jobs.push({ key, title: `Coming up - ${fmtTime(e.start)}`, message: `${e.title}${e.owner ? ` (${e.owner})` : ""}${e.location ? ` — ${e.location}` : ""}`, callName: e.customer, callPhone: e.phone });
  }
  for (const m of state.emails) {
    if (m.status === "sent" || !m.sendAt) continue;
    const t = localToDate(m.sendAt); if (!t) continue;
    const key = `em:${m.id}:${m.sendAt}`;
    if (log[key] || t.getTime() > nowMs || nowMs - t.getTime() > 60 * 60e3) continue;
    jobs.push({ key, title: "Time to send an email", message: `${m.subject} → ${m.to || "recipient"}` });
  }

  const results = [];
  for (const j of jobs.slice(0, 10)) {
    try { results.push({ key: j.key, sent: await notify(j) }); log[j.key] = nowMs; }
    catch (e) { results.push({ key: j.key, error: String(e.message || e) }); }
  }
  // Keep the log small: forget entries older than 3 days.
  for (const [k, t] of Object.entries(log)) if (nowMs - t > 3 * 864e5) delete log[k];
  if (jobs.length) await setJSON("pushlog", log);
  return { checked: true, sent: results.length, results, addressedTo: addr };
}

export default async () => {
  const r = await runAlerts();
  console.log("CHIEF alerts", JSON.stringify(r));
  return new Response(JSON.stringify(r), { headers: { "content-type": "application/json" } });
};

export const config = { schedule: "*/5 * * * *" };
